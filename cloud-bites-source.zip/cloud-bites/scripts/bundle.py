from pathlib import Path
import re,base64,mimetypes,zipfile,sys
root=Path(__file__).resolve().parents[1];dist=root/'dist';out=Path(sys.argv[1]).resolve();out.mkdir(parents=True,exist_ok=True)
parts=[]
for filename in ['content.js','advanced.js','engine.js','app.js']:
 s=(dist/'assets'/filename).read_text();s=re.sub(r'^import .*?;\n','',s,flags=re.M);s=re.sub(r'^export ','',s,flags=re.M)
 if filename=='advanced.js':
  for img in (dist/'assets/pdf-images').iterdir():
   uri='data:'+mimetypes.guess_type(img.name)[0]+';base64,'+base64.b64encode(img.read_bytes()).decode();s=s.replace('./assets/pdf-images/'+img.name,uri)
 parts.append(s)
js='\n'.join(parts);(out/'cloud-bites-bundle-check.mjs').write_text(js)
html=(dist/'index.html').read_text();html=re.sub(r'<link rel="icon"[^>]+>','',html);html=html.replace('<link rel="stylesheet" href="./assets/style.css">','<style>'+(dist/'assets/style.css').read_text()+'</style>');html=html.replace('<script type="module" src="./assets/app.js"></script>','<script type="module">'+js.replace('</script','<\\/script')+'</script>');(out/'cloud-bites.html').write_text(html)
with zipfile.ZipFile(out/'cloud-bites-source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in root.rglob('*'):
  if f.is_file() and not any(x.startswith('.') for x in f.relative_to(root).parts):z.write(f,Path('cloud-bites')/f.relative_to(root))
print('Bundled:',len(html.encode()),'bytes')
