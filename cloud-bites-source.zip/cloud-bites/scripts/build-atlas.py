from pathlib import Path
import json,re,sys
root=Path(__file__).resolve().parents[1]
data=json.loads((root/'dist/assets/services-data.json').read_text())
template=(root/'scripts/atlas-template.html').read_text()
html=template.replace('__ATLAS_DATA__',json.dumps(data,ensure_ascii=False).replace('</script','<\\/script'))
(root/'dist/aws-services.html').write_text(html)
if len(sys.argv)>1:
 out=Path(sys.argv[1]).resolve();out.mkdir(exist_ok=True,parents=True);(out/'aws-services.html').write_text(html)
 md=['# AWS SAA-C03 서비스 도감','',f'공식 예시 목록 118개(중복 제외), 보충 기능 18개. 확인일 {data["checked"]}.','공식 목록도 비포괄적이며 변경 가능하므로 실제 출제의 모든 서비스를 보장하는 목록은 아닙니다.','',f'공식 범위: {data["scopeURL"]}','','## 대표 구성 6가지','', '그림의 화살표는 처리·전달 또는 표시된 제어 관계를 뜻합니다. 네트워크 배치의 세부 조건은 HTML 도감에서 함께 확인하세요.','']
 diagrams=[('멀티 AZ 웹앱','flowchart TD\n U[사용자] -->|DNS 조회| D[Route 53]\n D -->|대상 주소 응답| U\n U -->|HTTPS| C[CloudFront + 연결된 WAF]\n C --> L[ALB - 두 AZ 퍼블릭 서브넷]\n L --> A[EC2 A - 프라이빗 앱 서브넷]\n L --> B[EC2 B - 프라이빗 앱 서브넷]\n A --> P[RDS Primary - AZ A]\n B --> P\n P -->|동기 복제| S[Standby - AZ B / 앱 읽기 불가]\n C -->|정적 콘텐츠 / OAC| O[S3 - 리전 서비스 / VPC 밖]'),('서버리스 요청과 비동기 작업','flowchart LR\n U[고객] --> C[Cognito 로그인]\n U -->|JWT| G[API Gateway]\n G --> F[Lambda]\n F --> D[DynamoDB]\n F --> N[SNS]\n N --> Q[SQS 소비자별 큐]\n Q --> W[작업자 Lambda]'),('데이터 레이크','flowchart LR\n E[이벤트] --> K[Kinesis Data Streams]\n K --> F[Firehose]\n F --> S[S3 원본]\n S --> G[Glue ETL]\n G --> P[S3 정제 데이터]\n A[Athena] -->|파일 읽기| P\n C[Glue Catalog] -.->|메타데이터| A\n A --> V[Quick Sight]'),('하이브리드와 이전','flowchart LR\n O[회사망] --> X[Direct Connect 또는 Site-to-Site VPN]\n X --> T[Transit Gateway]\n T --> V[VPC]\n NAS[파일 서버] --> S[DataSync]\n S --> FS[S3 / EFS / FSx]\n DB[원본 DB] --> D[DMS / CDC]\n D --> R[대상 DB]\n M[원본 서버] --> A[MGN]\n A --> EC[EC2]'),('권한과 관측','flowchart TD\n E[직원 IdP] --> I[Identity Center]\n I --> R[IAM 역할]\n R --> A[AWS 리소스]\n A -.->|지표·로그| C[CloudWatch]\n A -.->|API 활동 기록| T[CloudTrail]\n A -.->|구성 상태| F[Config]\n A -.->|분산 요청 추적| X[X-Ray]'),('저장소 선택','flowchart LR\n E[EC2 / 블록 I/O] --> B[EBS - AZ 범위]\n L[Linux 앱 / NFS] --> F[EFS - Regional 또는 One Zone]\n W[특정 파일시스템] --> X[FSx - Windows / Lustre / ONTAP / OpenZFS]\n O[객체 API] --> S[S3]\n S -->|Lifecycle| G[S3 Glacier 클래스]\n R[지원 리소스] --> V[AWS Backup 복구 지점]')]
 for title,diagram in diagrams:md+=['### '+title,'','```mermaid',diagram,'```','']
 for group in data['groups']:
  md+=['## '+group['title'],'','| 서비스 | 역할 | 배치·연결 위치 | 작동 흐름 | 선택 기준·주의 |','|---|---|---|---|---|']
  for s in data['services']:
   if s['scope']!='official' or not (s['category']==group['id'] or group['id'] in s['also']):continue
   md.append('| '+ ' | '.join([s['name'],s['role'],s['where'],s['flow'],s['tip']])+' |')
   if s.get('notice'):md+=['',f'> {s["name"]}: {s["notice"]}','']
  md+=['']
 md+=['## 보충 기능 18개','','| 기능 | 역할 | 위치 | 흐름 | 주의 |','|---|---|---|---|---|']
 for s in data['services']:
  if s['scope']=='supplement':md+=['| '+' | '.join([s['name'],s['role'],s['where'],s['flow'],s['tip']])+' |']
 md+=['','## 참고 문서','']+['- '+u for u in sorted({s['source'] for s in data['services']})]
 (out/'AWS-SAA-서비스-도감.md').write_text('\n'.join(md)+'\n')
 (out/'aws-services-script-check.mjs').write_text(re.search(r'<script>(.*?)</script>',html,re.S)[1])
print('Built atlas',len(html.encode()),'bytes')
