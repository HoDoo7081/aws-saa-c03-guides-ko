# 클라우드 한입

하루 8문제로 익히는 한국어 AWS SAA 학습 웹앱. 빌드 없이 동작하는 HTML/CSS/ES 모듈 프로젝트입니다.

## 실행

```sh
python3 -m http.server 5173 --directory dist
```

브라우저에서 http://localhost:5173 을 열면 됩니다. `file://` 대신 HTTP 서버를 사용하세요.

```sh
node --test tests/*.test.js
```

## 구성

- `dist/assets/content.js`: 37개 주제, 111개 신규 작성 퀴즈와 한국어 가이드
- `dist/assets/advanced.js`: 사용자 제공 PDF 2권의 원문 1,094문항, 정답표·수록 해설·출처 페이지
- `dist/assets/pdf-images/`: 원문 이미지와 IAM 정책 선택지
- `dist/assets/engine.js`: 일일 목표·간격 복습·XP·연속 학습·백업 검증
- `dist/assets/app.js`: 대시보드·학습·지도·오답·기록·가이드·백업 UI
- `dist/assets/style.css`: 반응형 스타일과 reduced-motion 지원
- `tests/engine.test.js`: 날짜 경계, 복습, 중복 보상 방지 등 테스트

학습 데이터는 사용자의 해당 브라우저 localStorage에 저장됩니다. 서버 DB·자동 기기 동기화·푸시 알림은 없습니다. 백업 내보내기·가져오기로 이전할 수 있습니다. 한국 시간 기준 하루 목표 8개의 고유 문항, 정답 10XP·오답 5XP(문항당 하루 한 번), 오답은 세션에서 한 번 더 풀고 다음 날 복습합니다. 같은 날 재풀이는 최초 기록과 복습 단계를 바꾸지 않습니다. 반복되는 다른 날 정답은 1·3·7·14·30일 간격을 사용합니다.

Google Fonts를 불러오며 사용할 수 없으면 시스템 글꼴로 표시됩니다. 콘텐츠는 번들에 포함되어 외부 API 없이 동작합니다. 진도 백업에는 학습 기록이 포함됩니다.

## 출처

원작: RonitSachdev, https://github.com/RonitSachdev/aws-saa-c03-guides (CC BY 4.0).
한국어판: HoDoo7081, https://github.com/HoDoo7081/aws-saa-c03-guides-ko .
한국어 가이드는 번역·요약·재구성·정정본이며 퀴즈 문구는 이를 바탕으로 새로 작성했습니다. 원본 라이선스는 `SOURCE-NOTICES.md`를 참고하세요. 기본 111문항은 새로 작성한 연습 문제입니다. 심화 1,094문항은 사용자가 제공한 PDF 원문을 변환했습니다. AWS·Duolingo와 제휴하지 않습니다.

## 기출 심화

`SAA-C03_KOR(1).pdf` 500문항, `SAA-C03_KOR(2).pdf` 594문항을 순서대로 수록했습니다. 페이지 경계와 줄바꿈 공백은 정리하고 선택지 순서·문장·수록 정답을 유지했습니다. 원문 번호 오탈자는 유지하며 전체 수록 순서도 안내합니다. 검색, 매일 8문제, 최대 20문제씩 55세트, 단일/복수 정답, XP, 오답 복습을 지원합니다.

채점 및 해설은 PDF 정답표를 따릅니다. 실제 시험 출제 여부, 정답 정확성 및 최신 AWS 기능과의 일치는 검증하지 않았습니다. 자료에 표시된 정답 의문과 982~1019번 구간은 검토 대상으로 안내합니다. 일부 그림은 해당 페이지에서 추출한 원본 이미지로 제공하므로 원본 PDF 페이지와 함께 확인하세요. PDF 콘텐츠는 위 GitHub 가이드의 CC BY 4.0 라이선스 대상이 아닙니다. 원본 PDF 파일은 소스에 포함하지 않았습니다.

기존 localStorage 키와 기본 문항 ID를 유지하므로 이전 버전 기록을 읽을 수 있습니다. 웹 배포 주소는 아직 활성화되지 않았습니다. GitHub에서는 실행용 HTML과 전체 소스 ZIP을 제공합니다.

## AWS 서비스 도감

`dist/aws-services.html`에 공식 SAA-C03 예시 목록 118개(중복 제외)와 작동 이해를 위한 보충 기능 18개를 수록했습니다. 16개 분야별 역할·위치·흐름·선택 기준, 아키텍처 그림 6개와 서비스 비교 12개를 제공합니다. 2026-10-18 확인 기준이며 목록은 비포괄적·변경 가능입니다.

데이터: `dist/assets/services-data.json`
생성: `python3 scripts/build-atlas.py`
웹: https://hodoo7081.github.io/aws-saa-c03-guides-ko/aws-services.html
